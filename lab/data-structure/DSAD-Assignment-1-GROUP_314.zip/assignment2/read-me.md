1. clone this repo
2.open command line terminal
3.make sure input fiels are in same folder
3.run python3 ps2.py